<?php
/**
 * gallery post type
 */
class Custom_Post_Type_Gallery{
	
}