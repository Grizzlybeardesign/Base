<?php 
/**
 * Plugin recomondations
 *
 *
 * @package WordPress
 * @subpackage Grizzly theme
 */
	require_once 'class-tgm-plugin-activation.php';
	class Plugin_Recommendations{
	   public	function __construct(){
			
		}
	  /**
	   *  Get plugin recomondations
	   */	
	  public function init(){
	  	
	  }
	}
